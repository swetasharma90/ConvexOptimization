function [Pimg, K,original]=loadimage()
%%%%% Function to add Gaussian blur and Poisson noise to the image %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%I = imread('neuron.tif');
I = imread('cropped_image.tif');
I = rgb2gray(uint8(I));
original = I;
[k,l] = size(I);
%n = min(k,l);
n=64;
I = I(1:n,1:n);
original = original(1:n,1:n);
K = eye(n*n);
%%%%%%%%%%%% Gaussian Blur + Poisson noise %%%%%%%%%%%
[K,convI] = compK(I);

[Pimg] = noise(convI,n,n);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%% Poisson Noise %%%%%%%%%%%%%%%%%%%%%%%%%%
%[Pimg] = noise(I,n,n);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end