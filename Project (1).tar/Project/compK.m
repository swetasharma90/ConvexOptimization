function [K,convI] = compK(I)
%size of matrix to be blurred
[m,n] = size(I);
N = m*n;
blur_para = [3,1.0]; %blur_para(1) = kernel size , blur_para(2) = standard deviation

m_blur = blur_para(1) + (1-mod(blur_para(1),2)); %size of filter should be odd for sure
supp = (m_blur-1)/2;

% create kernel for Gaussian filter with size m_blur and
% standard deviation blur_std
H = fspecial('gaussian',[m_blur m_blur],blur_para(2));
    % ! quoted from fspecial.m for 'gaussian' (with own comments):
    %     rows = sze(1); cols = sze(2);       %here: rows = cols
    %     r2 = (rows-1)/2; c2 = (cols-1)/2;   %find center points
    %     [x,y] = meshgrid(-c2:c2, -r2:r2);   %discrete points
    % 	  radsqrd = x.^2 + y.^2;              %evaluate Gaussian kernel...
    % 	  f = exp(-radsqrd/(2*sigma^2));      %... at discrete points
    % 	  f = f/sum(f(:));                    %normalize

%%compute operator matrix K (gaussian filter)
d = ones(m,n,m_blur*m_blur+2);

%create diagonals of K
d(:,:,1) = H(supp+1,supp+1)*d(:,:,1);

d(:,:,2) = H(supp+2,supp+1)*d(:,:,2);
d(m,:,2) = H(supp+2,supp+2);

d(:,:,3) = H(supp,supp+2)*d(:,:,3);
d(1,:,3) = H(supp,supp+1);

d(:,:,4) = H(supp+1,supp+2)*d(:,:,4);

d(:,:,5) = H(supp+2,supp+2)*d(:,:,5);
d(m,:,5) = 0;

d(:,:,6) = zeros(m,n);
d(1,:,6) = H(supp,supp+2);

d(:,:,7) = zeros(m,n);
d(m,:,7) = H(supp+2,supp);

d(:,:,8) = H(supp,supp)*d(:,:,8);
d(1,:,8) = 0;

d(:,:,9) = H(supp+1,supp)*d(:,:,9);

d(:,:,10) = H(supp+2,supp)*d(:,:,10);

d(:,:,11) = H(supp,supp)*d(:,:,11);

d = reshape(d,N,1,m_blur*m_blur+2);

K = spdiags([[d(1,:,11);zeros(N-1,1)],[d(1:m-1,:,10);zeros(N-m+1,1)],[d(1:m,:,9);zeros(N-m,1)],...
    [d(1:m+1,:,8);zeros(N-m-1,1)],[d(1:m+n,:,7);zeros(N-m-n,1)],[d(1:N-m-n,:,6);zeros(m+n,1)],...
    [d(1:N-n-2,:,5);zeros(n+2,1)],[d(1:N-n-1,:,4);zeros(n+1,1)],...
    [d(1:N-n,:,3);zeros(n,1)],[d(1:N-1,:,2);0],d(:,:,1),[0;d(1:N-1,:,2)],...
    [zeros(n,1);d(1:N-n,:,3)],[zeros(n+1,1);d(1:N-n-1,:,4)],...
    [zeros(n+2,1);d(1:N-n-2,:,5)],[zeros(m+n,1);d(1:N-m-n,:,6)],...
    [zeros(N-m-n,1);d(1:m+n,:,7)],[zeros(N-m-1,1);d(1:m+1,:,8)],...
    [zeros(N-m,1);d(1:m,:,9)],[zeros(N-m+1,1);d(1:m-1,:,10)],[zeros(N-1,1);d(1,:,11)]],...
    [-(N-1) -(N-m+1) -(N-m) -(N-m-1) -(N-2*m-1) -(2*m-1) -(m+1) -m -(m-1) -1 0 ...
    1 m-1 m m+1 2*m-1 N-2*m+1 N-m-1 N-m N-m+1 N-1],N,N);
convI = K*reshape(double(I),[],1);
end

