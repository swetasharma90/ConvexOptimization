function [Y] = noise(x, m , n)
%%%%%%%% Function to add Poisson noise to the image %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x = reshape(x,[],1);
lambda = double(x);
Y = poissrnd(lambda);
Y = uint8(reshape(Y,m,n));
end


