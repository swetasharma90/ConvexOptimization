function [ B ] = imblur( I, sigma )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

B = imgaussfilt(I,sigma);
end


