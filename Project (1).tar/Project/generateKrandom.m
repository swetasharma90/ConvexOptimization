
function [K] = generateKrandom(m,n)
range1 = 0;
range2 = 1;
K = randi([range1 range2],m,n);
end
