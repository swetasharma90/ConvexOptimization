function   testtv()
I = imread('cropped_image.tif');
%I = imread('cameraman.tif');
I = rgb2gray(uint8(I));
original = I;
[k,l] = size(I);
n = min(k,l);
I = I(1:n,1:n);
original = original(1:n,1:n);
%imshow((I));

B = imblur(I,1);
%u = SB_ITV(double(B),8)
inpoptions.method = 'chambolle';
inpoptions.lambda = 0.008;
inpoptions.niter = 5;
u = perform_tv_denoising(double(B),n,n,inpoptions);
figure;
subplot(1,3,1)
imshow(uint8(I));
subplot(1,3,2)
imshow(uint8(B));
subplot(1,3,3)
imshow(uint8(u));

end