function [z] = pidaltv(u01, u02, u03, d01, d02, d03, mu, tau, K, Y,m,n,original)
%%%%%%%%%%%%%% Function to solve PIDAL-TV %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
u_k1 = u01;
u_k2 = u02;
u_k3 = u03;
d_k1 = d01;
d_k2 = d02; 
d_k3 = d03;
numiter = 40;
size(Y);
kinv = inv(K'*K + 2*eye(size(K)));
size(original)
original = double(original);
original'
Y'
p = zeros(size(sqrt(m),sqrt(m)));
epsilon = 0.5;
t = 1;
mae = []; 
num = sum((double(original(:)) - double(Y(:))).^2);
tic;
timeelapsed = [];
ISNR = [];
loglike = [];
while(1)
    't'
    t
   zi_k1 = u_k1 + d_k1;
   zi_k2 = u_k2 + d_k2;
   zi_k3 = u_k3 + d_k3;
   gamma_k = K'*zi_k1 + zi_k2 + zi_k3;
   'pinv'
   %%%%%%%%%%% For blurred and noisy image %%%
   z_k1 = kinv*gamma_k;
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
   %%%%%%%%% For just noised image %%%%%%%%%
   %z_k1 = (1/3)*eye(size(K))*gamma_k;
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   'pinvdone'
   nu_k1 = K*z_k1 - d_k1;
   u_k1 = minimization1(mu,nu_k1,Y);
   nu_k2 = z_k1 - d_k2;
   [u_k2] = minimization2(mu,nu_k2,tau,sqrt(m),sqrt(m));
   nu_k3 = z_k1 - d_k3;
   u_k3 = minimization3(mu,nu_k3);
    %if(norm(u_k3-z_k)<epsilon)
     % break; 
    %end
   'langrange params update'
   d_k1 = d_k1 - (K*z_k1 - u_k1);
   d_k2 = d_k2 - (z_k1 - u_k2);
   d_k3 = d_k3 - (z_k1 - u_k3);
   'langrange params update done'
   z_k = double(uint8(u_k3));
   loglike = [loglike; calcloglike(Y,z_k,m,tau,K)];
   timeelapsed = [timeelapsed toc];
   tic;
   'original'
   size(original,1)
   mae = [mae; norm(original-z_k,1)/(size(original,1))];
   den = sum((double(original(:)) - double(z_k(:))).^2);
   ISNR = [ISNR; 10*log10(num/den)];
   if(t==numiter)
       break;
   end
   t = t + 1;
end
z = u_k3;
save('z.mat','z');
'mae'
%figure;
%plot(1:size(mae,1),mae)
%figure;
%plot(1:size(ISNR,1),ISNR)
figure;

scatter(1:size(loglike,1),timeelapsed)
title('Iterations versus time taken');
xlabel('Number of iterations');
ylabel('Time taken in seconds');

figure;
plot(1:size(loglike,1),loglike);title('Iterations versus objective function value');
xlabel('Number of iterations');
ylabel('Objective function value');

end

function [u] = minimization1(mu,nu_k1,Y)
u = (1/2)*(double(nu_k1) - double(1/mu) + double(sqrt((nu_k1 - 1/mu).^2 + double(4*Y))));
end

function [u] = minimization2(mu,nu_k2,tau,m,n)
'sbtv'
%u = SB_ITV(nu_k2,tau);
%setoptions(options,);
inpoptions.method = 'chambolle';
inpoptions.lambda = tau;
inpoptions.niter = 5;
%[u] = perform_tv_denoising(mu*nu_k2,m,n,inpoptions);
u = SB_ITV(nu_k2*mu,tau);

u = u./mu;
'sbtv finished'
end

function [l] = calcloglike(Y,z_k,m,tau,K)

l = sum(K*z_k) + sum(-double(Y).*(K*z_k)) + tau*totalvariation(z_k,m);
end

function [tv] = totalvariation(z_k,m)
z = reshape(z_k,sqrt(m),sqrt(m));
[gradI_x, gradI_y] = imgradientxy(z);
tv = sum(sqrt(gradI_x.^2 + gradI_y.^2));
tv = sum(tv);
end

function [u] = minimization3(mu,nu_k3)
'max3'
u = max(nu_k3,0);
'max3 ended'
end