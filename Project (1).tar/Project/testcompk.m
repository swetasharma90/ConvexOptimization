I = imread('cropped_image.tif');
I = rgb2gray(uint8(I));
imshow(I);
[k,l] = size(I);
n = min(k,l);
I = I(1:n,1:n);
K = compK(I);
