[I, K,original] = loadimage();
[n,n]=size(I);
[counts, grayLevels] = imhist(original);
lastIndex = find(counts > 0, 1, 'last')
M = 50;  % M is set to maximum intensity level of the image grayLevels(lastIndex);
I = reshape(I,[],1);
original = reshape(original,[],1);
[m,m] = size(K);
d = zeros(n*n,1);
tau = 80;              % tau = 80 for just denoising with SB-ITV
%%%%%%%%%%%%%% Pidal-TV %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
z = pidaltv(double(I), double(I), double(I), d, d, d, tau*60/M, tau, K, I,m,m,original);
z = reshape(z,n,n);
z = uint8(z);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%% Pidal-FA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%P = ConstructHaarWaveletTransformationMatrix(n*n);
%z = pidalFA(double(I), P*double(I), double(I), d, d, d, tau*60/M, tau, K, I,m,m,original,P);
%z = reshape(z,n,n);
%z = uint8(z);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

original = reshape(original,n,n);
I = reshape(I,n,n);
figure;
subplot(1,3,1)
imshow(uint8(original));
subplot(1,3,2)
imshow(uint8(I));
subplot(1,3,3)
imshow(uint8(z));