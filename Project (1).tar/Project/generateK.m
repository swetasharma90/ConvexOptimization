function [K] = generateK(m,n)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

end

