function [fx,fy] = grad(M, options)

% grad - gradient, forward differences
%
%   [gx,gy] = grad(M, options);
% or
%   g = grad(M, options);


options.null = 0;
if isfield(options, 'bound')
    bound = options.bound;
else
    bound = 'sym';
end

if strcmp(bound, 'sym')
    fx = M([2:end],:)-M([1:end-1],:);
    fx = [fx;zeros(1,size(M,2))];
    fy = M(:,[2:end])-M(:,[1:end-1]);
    fy = [fy,zeros(size(M,1),1)];
else
    fx = M([2:end],:)-M([1:end-1],:);
    fx = [fx;zeros(1,size(M,2))];
    fy = M(:,[2:end])-M(:,[1:end-1]);
    fy = [fy,zeros(size(M,1),1)];
end

if nargout==1
    fx = cat(3,fx,fy);
end