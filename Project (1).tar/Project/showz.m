load('z.mat');
z = reshape(z,86,86);
z = uint8(z);
imshow(z);